🕹️Jogo do Amigo Secreto 🕹️

<img width="1828" height="892" alt="Captura de tela 2025-09-19 213038" src="https://github.com/user-attachments/assets/8e47c119-1e59-49f5-93c1-ab3ee6bd9a6c" />


Este projeto é o Challenge Amigo Secreto da primeira parte da formação em programação da ONE Oracle Next em parceria com Alura. 
O objetivo é criar um projeto que permita sortear um nome aleatoriamente entre os nomes adicionados em uma lista. 

Funcionalidades:

•  Ele permite adicionar os nomes dos seus amigos a lista. 

• É possível ver os nomes que já foram adicionados na lista.

• Sortear um nome entre os citados e realizar novos sorteios, sem que os nomes adicionados sejam perdidos. 


🛠️ Ferramentas Utilizadas.

JavaScript
HTML
CSS



Para executar você precisa baixar o arquivo zip do Código.
Ou você pode simplesmente abrir o seu terminal do VScode . 

<img width="525" height="497" alt="Imagem terminal" src="https://github.com/user-attachments/assets/101cac38-6fc3-41bc-a288-6a51871048eb" />

Copie o comando que está entre aspas logo abaixo e depois cole no seu terminal do VScode:

" git clone https://github.com/Eliabe645/Amigo-Secreto-Allura.git "





